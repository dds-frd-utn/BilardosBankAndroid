package com.example.dds_tp3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Pagar extends AppCompatActivity {

    Spinner opciones;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagar);

    opciones = findViewById(R.id.idSpinnerTipoPagos);

        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,
                R.array.tipoPago,R.layout.spinner_personalizado);

     opciones.setAdapter(adapter);

    }
    public void eventoMenu(View view){
        Intent ingresar = new Intent(this, Menu.class);
        startActivity(ingresar);

    }


}
